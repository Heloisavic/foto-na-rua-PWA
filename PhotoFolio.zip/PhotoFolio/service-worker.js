const CACHE_NAME = 'cool-cache';

// Add whichever assets you want to precache here:
const PRECACHE_ASSETS = [
    '/assets/',
    '/src/'
]

// Listener for the install event - precaches our assets list on service worker install.
self.addEventListener('install', event => {
    event.waitUntil((async () => {
        const cache = await caches.open(CACHE_NAME);
        cache.addAll['./index.html',

        './about.html',

        './contact.html',

        './gallery-single.html',

        './gallery.html',

        './sample-inner-page.html',

        './services.html',

        './assets/css/main.css',

        './assets/js/main.js',

        './assets/scss/Readme.txt',

        './assets/img/20.png',
        './assets/img/29.png',
        './assets/img/40.png',
        './assets/img/48.png',
        './assets/img/50.png',
        './assets/img/55.png',
        './assets/img/57.png',
        './assets/img/58.png',
        './assets/img/60.png',
        './assets/img/66.png',
        './assets/img/72.png',
        './assets/img/76.png',
        './assets/img/80.png',
        './assets/img/80.png',
        './assets/img/87.png',
        './assets/img/88.png',
        './assets/img/92.png',
        './assets/img/100.png',
        './assets/img/102.png',
        './assets/img/114.png',
        './assets/img/120.png',
        './assets/img/144.png',
        './assets/img/152.png',
        './assets/img/167.png',
        './assets/img/172.png',
        './assets/img/180.png',
        './assets/img/196.png',
        './assets/img/216.png',
        './assets/img/1024.png',


        './assets/img/favicon.png',
        './assets/img/profile-img.jpg',
        './assets/img/apple-touch-icon.png',


        './assets/img/fotonarua1.png',
        './assets/img/fotonarua2.png',
        './assets/img/fotonarua3.png',
        './assets/img/fotonarua4.png',
        './assets/img/fotonarua5.png',
        
        './assets/gallery/gallery-1.jpg',
        './assets/gallery/gallery-2.jpg',
        './assets/gallery/gallery-3.jpg',
        './assets/gallery/gallery-4.jpg',
        './assets/gallery/gallery-5.jpg',
        './assets/gallery/gallery-6.jpg',
        './assets/gallery/gallery-7.jpg',
        './assets/gallery/gallery-8.jpg',
        './assets/gallery/gallery-9.jpg',
        './assets/gallery/gallery-10.jpg',
        './assets/gallery/gallery-11.jpg',
        './assets/gallery/gallery-12.jpg',
        './assets/gallery/gallery-13.jpg',
        './assets/gallery/gallery-14.jpg',
        './assets/gallery/gallery-15.jpg',
        './assets/gallery/gallery-16.jpg',

        './assets/testimonials/testimonials-1.jpg',
        './assets/testimonials/testimonials-2.jpg',
        './assets/testimonials/testimonials-3.jpg',
        './assets/testimonials/testimonials-4.jpg',
        './assets/testimonials/testimonials-5.jpg',
      ]})
          );
    });
    

    self.addEventListener('message', function (event) {
      if (event.data.action === 'skipWaiting') {
        self.skipWaiting();
      }
    });
    
    self.addEventListener('fetch', function (event) {
      //Atualizacao internet
      event.respondWith(async function () {
         try {
           return await fetch(event.request);
         } catch (err) {
           return caches.match(event.request);
         }
       }());

});
